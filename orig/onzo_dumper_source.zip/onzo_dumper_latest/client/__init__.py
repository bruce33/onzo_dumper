# Embedded file name: client\__init__.pyo
if __name__ == '__main__':
    import client.ui
    client.ui.main()