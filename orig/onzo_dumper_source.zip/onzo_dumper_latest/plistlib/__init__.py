# Embedded file name: plistlib\__init__.pyo
pass