# Embedded file name: client\client_version.pyo
VERSION = '1.14.696'
DEBUG = +0