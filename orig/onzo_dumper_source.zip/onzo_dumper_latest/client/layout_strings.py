# Embedded file name: client\layout_strings.pyo
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
from client import internationalisation
icon_title = _('Dumper')
window_title = _('Dumper')
server_cross_text = _('Data server not connected')
server_tick_text = _('Data server connected')
device_cross_text = _('Your display is unavailable')
device_tick_text = _('Your display is connected')
devices_tick_text_sek = _('Your SEK display is connected')
devices_tick_text_zbd = _('Your Zigbee display is connected')