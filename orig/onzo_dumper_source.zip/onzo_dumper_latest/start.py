import sys, os
from client import ui
ui.main()