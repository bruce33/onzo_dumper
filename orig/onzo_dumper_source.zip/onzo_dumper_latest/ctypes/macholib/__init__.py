# Embedded file name: ctypes\macholib\__init__.pyo
__version__ = '1.0'